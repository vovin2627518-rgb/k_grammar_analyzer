import nltk

# Make sure the NLTK data is available
nltk.download('punkt', quiet=True)
nltk.download('averaged_perceptron_tagger', quiet=True)

def analyze_sentence(sentence: str):
    """
    Tokenize and tag parts of speech for a given sentence.
    """
    tokens = nltk.word_tokenize(sentence)
    tagged = nltk.pos_tag(tokens)
    return tagged
